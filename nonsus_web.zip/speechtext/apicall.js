function checkUrl() {
    var url = document.getElementById("link-input").value;
    var request = {
        "client": {
            "clientId": "your_client_id",
            "clientVersion": "1.0"
        },
        "threatInfo": {
            "threatTypes": ["MALWARE", "SOCIAL_ENGINEERING"],
            "platformTypes": ["WINDOWS"],
            "threatEntryTypes": ["URL"],
            "threatEntries": [{"url": url}]
        }
    };
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "https://safebrowsing.googleapis.com/v4/threatMatches:find?key=AIzaSyDHVTucuLpzMDarFuChuDRwOt3UNg38ofE");
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.onreadystatechange = function() {
        if (this.readyState === XMLHttpRequest.DONE && this.status === 200) {
            var response = JSON.parse(xhr.responseText);
            if (response.matches.length > 0) {
                alert("The entered link is unsafe!");
            } else {
                alert("The entered link is safe.");
            }
        }
    };
    xhr.send(JSON.stringify(request));
}
