import requests
import json

API_KEY = 'AIzaSyDHVTucuLpzMDarFuChuDRwOt3UNg38ofE'
API_URL = 'https://safebrowsing.googleapis.com/v4/threatMatches:find'

payload = {
    "client": {
        "clientId": "yourcompanyname",
        "clientVersion": "1.5.2"
    },
    "threatInfo": {
        "threatTypes": ["MALWARE", "SOCIAL_ENGINEERING"],
        "platformTypes": ["WINDOWS"],
        "threatEntryTypes": ["URL"],
        "threatEntries": [{"url": "http://www.example.com"}]
    }
}

params = {
    'key': API_KEY
}

response = requests.post(API_URL, params=params, json=payload)

if response.ok:
    data = json.loads(response.content)
    if data.get('matches'):
        print('The URL is potentially unsafe.')
    else:
        print('The URL is safe.')
else:
    print('An error occurred:', response.status_code, response.reason)
